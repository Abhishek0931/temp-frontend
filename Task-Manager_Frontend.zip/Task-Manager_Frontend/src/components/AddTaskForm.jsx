import { useState } from 'react';

export default function AddTaskForm({ onAdd }) {
  const [title, setTitle] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Title is required');
      return;
    }
    setError('');
    onAdd(title);
    setTitle('');
  };

  return (
    <form onSubmit={handleSubmit} style={{marginBottom:'1rem'}}>
      <input type="text" placeholder="Task title" value={title} onChange={e => setTitle(e.target.value)} />
      <button type="submit">Add Task</button>
      {error && <span style={{color:'red'}}>{error}</span>}
    </form>
  );
}
