# Task Manager Frontend

This is the React frontend for the Task Manager app. It connects to the backend API to manage tasks and users.

## Features
- Task list: fetch and display tasks
- Add task form with validation
- Update and delete tasks
- Error message if not logged in
- Filter tasks by status
- Sort tasks by title
- Login and registration

## Getting Started

### Prerequisites
- Node.js (v18+ recommended)

### Installation
1. Navigate to the `frontend-v2` folder:
	```sh
	cd frontend-v2
	```
2. Install dependencies:
	```sh
	npm install
	```
3. Create a `.env` file with:
	```env
	VITE_API_URL=http://localhost:5000/api
	```
4. Start the app:
	```sh
	npm run dev
	```

## API Integration
- The frontend expects the backend to be running at `http://localhost:5000/api`.
- Make sure CORS is enabled in the backend for `http://localhost:3000`.

## License
MIT
