import { useEffect, useState, useContext } from 'react';
import { AuthContext } from '../contexts/AuthContext';
import { getTasks, addTask, updateTask, deleteTask } from '../services/api';
import AddTaskForm from './AddTaskForm';
import FilterSortBar from './FilterSortBar';

export default function TaskList() {
  const { accessToken, logout } = useContext(AuthContext);
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const [sortAsc, setSortAsc] = useState(true);

  const fetchTasks = async () => {
    setError('');
    if (!accessToken) {
      setError('You must be logged in.');
      return;
    }
    const res = await getTasks(accessToken);
    if (Array.isArray(res)) {
      setTasks(res);
    } else {
      setError(res.message || 'Failed to fetch tasks');
      if (res.message && res.message.toLowerCase().includes('jwt')) logout();
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [accessToken]);

  const handleAdd = async (title) => {
    const res = await addTask(title, accessToken);
    if (res._id) fetchTasks();
    else setError(res.message || 'Failed to add task');
  };

  const handleUpdate = async (task) => {
    const newStatus = task.status === 'pending' ? 'completed' : 'pending';
    const res = await updateTask(task._id, { status: newStatus }, accessToken);
    if (res._id) fetchTasks();
    else setError(res.message || 'Failed to update task');
  };

  const handleDelete = async (id) => {
    const res = await deleteTask(id, accessToken);
    if (res._id) fetchTasks();
    else setError(res.message || 'Failed to delete task');
  };

  // Filter and sort
  let filtered = tasks;
  if (filter !== 'all') filtered = filtered.filter(t => t.status === filter);
  filtered = [...filtered].sort((a, b) => sortAsc ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title));

  return (
    <div>
      <AddTaskForm onAdd={handleAdd} />
      <FilterSortBar filter={filter} setFilter={setFilter} sortAsc={sortAsc} setSortAsc={setSortAsc} />
      {error && <div style={{color:'red'}}>{error}</div>}
      <ul>
        {filtered.map(task => (
          <li key={task._id}>
            <span>{task.title}</span>
            <span> ({task.status}) </span>
            <button onClick={() => handleUpdate(task)}>Update</button>
            <button onClick={() => handleDelete(task._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
