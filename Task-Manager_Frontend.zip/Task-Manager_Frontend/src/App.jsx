
import { useContext, useState } from 'react';
import { AuthProvider, AuthContext } from './contexts/AuthContext';
import TaskList from './components/TaskList.jsx';
import Login from './components/Login.jsx';
import Register from './components/Register.jsx';

function AppContent() {
  const { accessToken, logout } = useContext(AuthContext);
  const [showRegister, setShowRegister] = useState(false);

  if (!accessToken) {
    return (
      <div style={{maxWidth:400,margin:'2rem auto'}}>
        {showRegister ? (
          <Register onRegistered={() => setShowRegister(false)} />
        ) : (
          <Login />
        )}
        <button onClick={() => setShowRegister(s => !s)} style={{marginTop:'1rem'}}>
          {showRegister ? 'Back to Login' : 'Register'}
        </button>
      </div>
    );
  }

  return (
    <div style={{maxWidth:600,margin:'2rem auto'}}>
      <button onClick={logout} style={{float:'right'}}>Logout</button>
      <h1>Task Manager</h1>
      <TaskList />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
