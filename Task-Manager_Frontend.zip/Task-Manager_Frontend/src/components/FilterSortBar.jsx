export default function FilterSortBar({ filter, setFilter, sortAsc, setSortAsc }) {
  return (
    <div style={{marginBottom:'1rem'}}>
      <label>Status: </label>
      <select value={filter} onChange={e => setFilter(e.target.value)}>
        <option value="all">All</option>
        <option value="pending">Pending</option>
        <option value="completed">Completed</option>
      </select>
      <button onClick={() => setSortAsc(!sortAsc)}>
        Sort by Title {sortAsc ? '▲' : '▼'}
      </button>
    </div>
  );
}
